## FPC2532 Enroll Identify example application

Demo application. Suitable for any microcontroller.
Use a HW button to start enrolling and show authentication result using LED.
