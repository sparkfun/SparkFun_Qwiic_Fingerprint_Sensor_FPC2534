## FPC2532 Navigation example application

Demo application. Suitable for any microcontroller.
Navigation mode will be started when running and gestures will be written to
console.
