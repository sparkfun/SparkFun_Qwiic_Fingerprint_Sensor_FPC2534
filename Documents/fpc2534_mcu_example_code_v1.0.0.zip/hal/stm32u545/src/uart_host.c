/*
 * Copyright (c) 2024 Fingerprint Cards AB
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file    uart_host.c
 * @brief   UART for Host communication.
 */

#include <stdbool.h>
#include <string.h>

#include "stm32u5xx_hal.h"

#include "usart.h"

#include "uart_host.h"

extern DMA_HandleTypeDef handle_GPDMA1_Channel0;

#define huart_host hlpuart1
#define uart_host_hdma_rx handle_GPDMA1_Channel0

#define MIN_DELAY_BETWEEN_CS_TOGGLE_AND_UART_TRANSFER_MS 2

#ifndef MIN
#define MIN(a, b)  (((a) < (b)) ? (a) : (b))
#endif

typedef struct
{
    volatile uint8_t flag;      /* Timeout event flag */
    uint16_t prev_cndtr;        /* Holds previous value of DMA_CNDTR (counts down) */
    uint32_t idle_irq_count;    /* Debug */
    uint32_t rx_complete_count; /* Debug */
    uint32_t rx_half_count;     /* Debug */
} dma_event_t;


static bool ignore_first_idle_irq = true;
static volatile bool tx_half;
static volatile bool tx_done;
static volatile bool error;
static volatile bool rx_available;

#define DMA_BUF_SIZE   128
#define DMA_TIMEOUT_MS 2

static uint8_t uart_rx_fifo[DMA_BUF_SIZE];
static dma_event_t dma_uart_rx = { 0, DMA_BUF_SIZE, 0, 0, 0 };

/**
 * This function handles Host USART global interrupt.
 */
void host_uart_irq_handler(void)
{
    /* UART IDLE Interrupt */
    if ((huart_host.Instance->ISR & USART_ISR_IDLE) != RESET) {
        huart_host.Instance->ICR = UART_CLEAR_IDLEF;
        if (ignore_first_idle_irq) {
            ignore_first_idle_irq = false;
        }
        else {
            dma_uart_rx.flag = 1;
            dma_uart_rx.idle_irq_count++;
            if(uart_host_hdma_rx.XferCpltCallback != NULL) {
                uart_host_hdma_rx.XferCpltCallback(&uart_host_hdma_rx);
            }
        }
    }
}


/**
 * USART init function.
 */
void uart_host_init(void)
{
    HAL_StatusTypeDef status;

    MX_LPUART1_UART_Init();

    /* Clear IDLE Flag */
    __HAL_UART_CLEAR_FLAG(&huart_host, UART_CLEAR_IDLEF);
    /* Enable UART IDLE interrupt */
    ATOMIC_SET_BIT(huart_host.Instance->CR1, USART_CR1_IDLEIE);

    /* Start UART RX */
    status = HAL_UART_Receive_DMA(&huart_host, uart_rx_fifo, DMA_BUF_SIZE);
    if (status != HAL_OK) {
        //fpc_util_handle_error(FPC_BEP_RESULT_GENERAL_ERROR);
    }
}

void uart_host_reinit(void)
{
    if (huart_host.Init.BaudRate) {
        huart_host.Instance->BRR = (uint16_t)(UART_DIV_SAMPLING16(SystemCoreClock,
                huart_host.Init.BaudRate, huart_host.Init.ClockPrescaler));
    }
}

/**
 * Initialize UART GPIO.
 * @param[in, out] huart UART Handle.
 */

int uart_host_transmit(uint8_t *data, size_t size, uint32_t timeout, int flush)
{
    HAL_StatusTypeDef status = HAL_ERROR;
    uint32_t tickstart = HAL_GetTick();

    tx_half = false;
    tx_done = false;
    error = false;

    /* Toggle CS to wakeup device and wait before starting transfer */
    HAL_GPIO_WritePin(FPC2530_CS_N_GPIO_Port, FPC2530_CS_N_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(FPC2530_CS_N_GPIO_Port, FPC2530_CS_N_Pin, GPIO_PIN_SET);
    HAL_Delay(MIN_DELAY_BETWEEN_CS_TOGGLE_AND_UART_TRANSFER_MS);

    status = HAL_UART_Transmit_DMA(&huart_host, data, size);
    if (status == HAL_TIMEOUT) {
        goto exit;
    } else if (status != HAL_OK) {
        goto exit;
    }

    while (!tx_done) {

        __WFI();

        if (error) {
            status = HAL_ERROR;
            goto exit;
        }

        if (timeout != 0 && (HAL_GetTick() - tickstart > timeout)) {
            if (tx_half) {
                /* We have an active transfer, reset timeout to not cut off
                 * half a transfer that is ongoing */
                tickstart = HAL_GetTick();
                tx_half = false;
            } else {
                HAL_UART_DMAStop(&huart_host);
                status = HAL_TIMEOUT;
                goto exit;
            }
        }
    }
exit:
    return status;
}

int uart_host_receive(uint8_t *data, size_t size, uint32_t timeout)
{
    int rc = 0;
    //HAL_StatuypeDef status = HAL_OK;
    uint32_t tickstart = HAL_GetTick();

    error = false;

    /* If no size return OK */
    if (!size) {
        goto exit;
    }

    if (huart_host.RxState != HAL_UART_STATE_BUSY_RX) {
        // Assert here
    }

    if (__HAL_DMA_GET_COUNTER(&uart_host_hdma_rx) == dma_uart_rx.prev_cndtr) {
        __WFI();
    }

    /* Check and read from RX FIFO */
    while (size) {
        uint16_t curr_cndtr = __HAL_DMA_GET_COUNTER(&uart_host_hdma_rx);

        if (curr_cndtr != dma_uart_rx.prev_cndtr) {
            uint32_t cur_pos = DMA_BUF_SIZE - curr_cndtr;
            uint32_t prev_pos;
            uint32_t length;

            /* Determine start position in DMA buffer based on previous CNDTR value */
            prev_pos = DMA_BUF_SIZE - dma_uart_rx.prev_cndtr;
            if (prev_pos < cur_pos) {
                length = MIN(cur_pos - prev_pos, size);
            } else {
                /* Copy until end of buffer first */
                length = MIN(DMA_BUF_SIZE - prev_pos, size);
            }
            memcpy(data, &uart_rx_fifo[prev_pos], length);
            data += length;
            size -= length;
            dma_uart_rx.prev_cndtr -= length;
            if (dma_uart_rx.prev_cndtr == 0) {
                dma_uart_rx.prev_cndtr = DMA_BUF_SIZE;
            }
            if (prev_pos > cur_pos) {
                /* Copy from start of buffer */
                length = MIN(cur_pos, size);
                memcpy(data, uart_rx_fifo, length);
                data += length;
                size -= length;
                dma_uart_rx.prev_cndtr -= length;
            }
            if (!size) {
                goto exit;
            }
        }

        __WFI();
        if (error) {
            rc = -1;
            goto exit;
        }
        if (timeout != 0 && (HAL_GetTick() - tickstart > timeout)) {
            rc = -1;
            goto exit;
        }
    }

exit:
    if (__HAL_DMA_GET_COUNTER(&uart_host_hdma_rx) == dma_uart_rx.prev_cndtr) {
        rx_available = false;
    }
    return rc;
}

uint32_t uart_host_rx_data_available(void)
{
    return rx_available ? 1 : 0;
}

void HAL_UART_RxHalfCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == huart_host.Instance) {
        rx_available = true;
        dma_uart_rx.rx_half_count++;
    }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == huart_host.Instance) {
        uint16_t curr_cndtr = __HAL_DMA_GET_COUNTER(huart->hdmarx);

        /*
         * Ignore IDLE Timeout when the received characters exactly filled up the DMA buffer and
         * DMA Rx Complete Interrupt is generated, but there is no new character during timeout.
         */
        if (dma_uart_rx.flag && curr_cndtr == DMA_BUF_SIZE) {
            dma_uart_rx.flag = 0;
            return;
        }

        if (!dma_uart_rx.flag) {
            dma_uart_rx.rx_complete_count++;
        }
        dma_uart_rx.flag = 0;

        rx_available = true;
    }
}

void HAL_UART_TxHalfCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == huart_host.Instance) {
        tx_half = true;
    }
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == huart_host.Instance) {
        tx_done = true;
    }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == huart_host.Instance) {
        //error = true;
        uart_host_rx_data_clear();
    }
}


void uart_host_rx_data_clear()
{
    HAL_UART_DMAStop(&huart_host);
    dma_uart_rx.prev_cndtr = DMA_BUF_SIZE;
    rx_available = false;
    ignore_first_idle_irq = true;
    (void)HAL_UART_Receive_DMA(&huart_host, uart_rx_fifo, DMA_BUF_SIZE);
}
