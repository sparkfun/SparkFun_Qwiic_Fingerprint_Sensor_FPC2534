## FPC2534 Secure Communication (Template Get/Put) example application

Demo application. Suitable for any microcontroller.
Use a HW button to restart example.
Example steps:
1. Will try to enable "factory reset" support in system config.
3. Enable secure communication on device by writing keys (if not already enabled) and restart.
4. Enroll (secure mode)
5. Get enrolled template (secure mode)
6. Put template (secure mode)
8. Wait for button press.
7. Do factory reset (secure mode)
8. Wait for button press to restart from 1.
