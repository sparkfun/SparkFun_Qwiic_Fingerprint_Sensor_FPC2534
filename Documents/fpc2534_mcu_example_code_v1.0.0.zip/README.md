## FPC2532 example applications

There are 3 main folders in the project:

- [examples](Examples) - HW-independed application examples
- [fpc2532_sdk](FPC2532_SDK) - FPC2532 SDK
- [hal](hal) - implementation of HW-dependent functions

------------

## Build system

There are some variables controlling application building:

- APP - defines application
- PLATFORM - defines HW plaform with HAL implementation
- DEBUG - if defined as 'y' will produce debug output and add debug information
- INTERFACE - if defined as uart, HAL will use UART interface. Else it will use SPI interface

Example build command (spi):
`make APP=enroll_identify PLATFORM=stm32u545 DEBUG=y`

Example build command (uart):
`make APP=enroll_identify PLATFORM=stm32u545 INTERFACE=uart DEBUG=y`

There are some useful makefile targets:

- Show all available applications:
    - `make list_apps`
- Show all available platforms:
    - `make list_hals`
- Clean output for particular application and platform:
    - `make PLATFORM=stm32u545 APP=enroll_identify clean`
- Clean output for all applications and platforms:
    - `make clean_all`

------------

### FPC HAL interface functions

For porting the project to a new microcontroller, all functions from [fpc_hal.h](fpc2532_sdk/inc/fpc_hal.h) must be implemented.

#### Functions that must be implemented:

| FPC HAL functions | Description |
| :---------------- | :---------- |
| fpc_result_t **fpc_hal_init**(void) | Initilalizes hardware |
| fpc_result_t **fpc_hal_tx**(uint8_t *data, size_t len, uint32_t timeout, int flush) | Send data packet to FPC2532 using selected interface |
| fpc_result_t **fpc_hal_rx**(uint8_t *data, size_t len, uint32_t timeout) | Receive data packet from FPC2532. If timeout = **0**, the function will wait for data from FPC2532 indefinitely. |
| int **fpc_hal_data_available**(void) | Check if the FPS Module has its IRQ signal active or data in rx buffer |

------------

### Common HAL implementation

Optional functions for implementting user interface in example_app, [hal_common.h](hal/inc/hal_common.h).


|  HAL Function |  Description |
| :------------ | :------------ |
| uint32_t **hal_check_button_pressed**(void) | Returns duration in ms the button was pressed |
| void **hal_set_led_status**(hal_led_status_t status) |  Set LED status |

------------

### Some notes about FPC2532 HW interface

- FPC2532 support both UART and SPI communication interface. The used interface is configured by setting the if_config pin(s) to the desired mode.
- **IRQ** pin is used in SPI mode only. The module set it to **High** when it has some data to send and set it to **Low** when data packet is sent.
